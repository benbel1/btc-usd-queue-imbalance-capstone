# Launcher verification — 25 September 2026

The 48-hour pilot has NOT been started. The only live run requested 0.025 hours (90 seconds).

## Installed files

- `%LOCALAPPDATA%\CapstoneBTC\start_pilot.cmd`
- `%LOCALAPPDATA%\CapstoneBTC\monitor_pilot.py`

Existing project code under Documents is unchanged. The launcher uses the existing `venv312\Scripts\python.exe`; it does not install dependencies or create an environment. Each invocation creates a new UTC timestamped `data\pilot-*` folder, runs dependency and research checks, collects data, then runs pilot analysis on successful collection.

## Verification results

Write/read/delete in the CapstoneBTC root succeeded after agent approval. No security settings or configuration were changed.

The detached Windows launcher returned control to the invoking process while supervisor PID 3084 and collector PID 7732 kept running. Status updates were observed at 20:34:14 and 20:34:28 UTC after the launcher returned. Collection completed at 20:34:45 UTC and analysis completed at 20:35:04 UTC. All three test processes exited.

The live run captured 1,461 messages, 90 observation seconds, and 89 valid seconds, with no connection errors. Collector exit code was 0. Analysis generated coverage, features, descriptive statistics and a plot. Predictive model evaluation correctly declined to run because this short test had fewer than 100 eligible rows in a split.

Dependency checks and all 10 existing research tests passed. Both monitor tests passed: incomplete CSV lines are deferred correctly, invalid observations do not refresh the valid-observation timestamp, missing/stale data produces an alert event, and unexpected exit code 7 is recorded. The first sandboxed fault-test attempt could not write inside temporary test directories; rerunning with approval passed.

## Monitoring and logs

The helper is a local Python supervisor, with no interactive session or network service dependency for monitoring. Windows must remain running and awake. Closing its console or terminating the supervisor stops monitoring; it is not a reboot-persistent Windows service.

Default polling is every 5 seconds. After 60 seconds without fresh observed timestamps, `stale_observations` is logged. Fresh rows without fresh valid observations produce `stale_valid_observations`. Recovery is logged as `healthy`. Staleness records an alert but does not terminate collection. Every collector exit is recorded; unsuccessful or unexpectedly early collection prevents analysis and gives a failed outcome. Alerts are local log events, not desktop notifications.

Within each run folder:

- `run.json`: settings, interpreter, source directory and supervisor PID.
- `preflight.log`: dependency checks and research tests.
- `collector.log`: persistent collector stdout/stderr.
- `monitor.jsonl`: timestamped health changes, termination and completion events.
- `status.json`: latest collector state, PIDs and observation ages; updated during collection.
- `analysis.log`: persistent analysis stdout/stderr.
- `outcome.json`: final run success or failure, and model-evaluation status.
- `collection`: raw feed, observations and metadata.
- `results`: analysis artifacts.

The verification directory also preserves the detached launch's stdout/stderr, launch details, fault tests and their passing log. `created-files.txt` lists every retained file created by this task.

## Commands for later use

Do not run the no-argument command until the 48-hour pilot is authorized:

```bat
"%LOCALAPPDATA%\CapstoneBTC\start_pilot.cmd"
```

To repeat only the short test:

```bat
"%LOCALAPPDATA%\CapstoneBTC\start_pilot.cmd" --hours 0.025 --poll-seconds 2 --stale-seconds 60
```

Leave the launcher console open during a manually started run. The earlier launcher in Documents remains unchanged; use the installed LocalAppData launcher for future runs.
