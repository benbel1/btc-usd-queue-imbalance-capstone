import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('monitor_pilot', ROOT / 'monitor_pilot.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


class MonitorTests(unittest.TestCase):
    def test_stale_data_and_unexpected_exit(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            run = Path(folder)
            process = subprocess.Popen([sys.executable, '-B', '-c',
                                        'import time; time.sleep(0.8); raise SystemExit(7)'])
            code = helper.monitor(process, run, time.time(), 0.1, 0.2)
            events = [json.loads(line) for line in (run / 'monitor.jsonl').read_text().splitlines()]
            self.assertEqual(code, 7)
            self.assertIn('stale_observations', [item['event'] for item in events])
            self.assertEqual(events[-1]['event'], 'collector_terminated')
            status = json.loads((run / 'status.json').read_text())
            self.assertFalse(status['collector_running'])
            self.assertEqual(status['collector_exit_code'], 7)

    def test_partial_line_and_invalid_observations(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            path = Path(folder) / 'observations.csv'
            path.write_bytes(b'timestamp,valid\r\n2026-09-25T20:00:00+00:00,1\r\n2026-09-25T20:00:01')
            reader = helper.Observations(path)
            reader.update()
            first = reader.latest
            with path.open('ab') as stream:
                stream.write(b'+00:00,0\r\n')
            reader.update()
            self.assertEqual(reader.latest, first + 1)
            self.assertEqual(reader.valid, first)
            reader.update()
            self.assertEqual(reader.latest, first + 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
