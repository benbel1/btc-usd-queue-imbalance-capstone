# Completed BTC pilot research handoff

Collection: 2026-09-25T20:45:37.371809+00:00 to 2026-09-27T20:45:37.440195+00:00. Analysis completed: 2026-09-27T20:46:41.102225+00:00.
Source run: [REDACTED_LOCAL_PATH]

## Counts and chronological split
172,800 observation seconds; 172,022 valid (99.54977%); 778 invalid. 2,861,006 feed messages. 171,455 eligible feature rows. Eligibility requires all 71 seconds in [t-60,t+10] valid in one session and finite predictors/target.
Validation boundary: 2026-09-27T01:33:37.400000+00:00; test boundary: 2026-09-27T11:09:37.200000+00:00. Boundaries use 60%/80% elapsed grid time, not row-count quantiles. Training and validation labels must end strictly before their next boundary; 20 eligible rows are purged.

| Partition | Rows | First eligible timestamp (UTC) | Last eligible timestamp (UTC) |
|---|---:|---|---|
| train | 102670 | 2026-09-25 20:46:39+00:00 | 2026-09-27 01:33:27+00:00 |
| validation | 34550 | 2026-09-27 01:33:38+00:00 | 2026-09-27 11:09:27+00:00 |
| test | 34215 | 2026-09-27 11:09:38+00:00 | 2026-09-27 20:45:27+00:00 |
| purged | 20 | 2026-09-27 01:33:28+00:00 | 2026-09-27 11:09:37+00:00 |

## Held-out metrics
Target: 10-second log midprice return multiplied by 10,000. Baseline ridge uses 1/5/10-second returns, 60-second volatility, spread and log depth; augmented adds book imbalance; zero predicts zero return. StandardScaler and ridge fit on training for alpha selection, then refit on training plus validation. Selected alpha: baseline 100, augmented 0.01.

| Model | MSE (bps²) | RMSE (bps) | MAE (bps) |
|---|---:|---:|---:|
| baseline | 1.860425550 | 1.363974175 | 0.782773626 |
| augmented | 1.841004867 | 1.356836345 | 0.810911612 |
| zero | 1.858609492 | 1.363308290 | 0.777047221 |

Augmented relative MSE reduction vs baseline: 1.0439%. Full nonoverlapping 10-second metrics, subgroup results and version metadata are in results/summary.json.

## Warnings
- Exploratory pilot only; one test calendar day. No paired-day bootstrap confidence interval estimated. No statistical significance or trading-profit claim is supported.
- Augmented MSE improves slightly, but its MAE is worse than both baseline and zero-return. Main metrics use overlapping 10-second targets; the nonoverlapping sensitivity metrics are also included.
- Connection interruptions and invalid rows affect coverage; see INTERRUPTION_SUMMARY.md and interruption_intervals.csv. Invalid seconds are not the same as 60-second monitor alert durations.
- First and last calendar days are partial; fraction_of_full_day_valid in coverage.csv should not be interpreted as outage rate.
- Original smoke verification predates the completed pilot: its statement that the 48-hour pilot had not started describes that earlier time. Smoke model evaluation was deliberately skipped for insufficient samples; the completed 48-hour evaluation succeeded.
- Launcher is a copy of the installed Windows script and requires the external venv312 and existing project path. Running it starts a NEW run; do not launch it just to inspect this package. Supervisor is not reboot-persistent.

## Contents and exclusions
All analysis outputs including features, predictions, coverage, daily losses, descriptive statistics and distributions.png; observations and metadata; outcome and small diagnostic logs; launcher and monitor; original verification evidence. Raw feed raw.jsonl.gz, environment directories, caches, credentials and unrelated files are excluded by explicit allowlist. Local path names in provenance are retained. No originals were changed.

## Verification
Original dependency check and all 10 research tests passed. Original two monitor fault tests passed; detached 90-second collection demonstrated operation independent of an interactive session (see original report). Completed collector exit code 0, completed outcome and run_completed event agree. Both pilot processes exited normally; hourly health task was paused. Packaging streamed observation and feature counts and reconciled them to metadata and saved split counts. MANIFEST.json contains SHA-256 hashes of all payload files; ZIP CRC and payload hashes were checked after writing.
