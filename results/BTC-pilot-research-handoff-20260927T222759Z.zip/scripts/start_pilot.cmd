@echo off
setlocal
set "PYTHON=%~dp0venv312\Scripts\python.exe"
if not exist "%PYTHON%" (
  echo Missing external Python environment: %PYTHON%
  exit /b 1
)
rem No arguments starts the 48-hour pilot. Use --hours 0.025 for a 90-second test.
rem The supervisor and collector run as independent local processes.
"%PYTHON%" -B -u "%~dp0monitor_pilot.py" %*
exit /b %errorlevel%
